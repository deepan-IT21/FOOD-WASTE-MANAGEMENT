package com.example.myapplication;

public class User {
    public String name,email;

    public User(){

    }

    public User(String name, String email){
        this.name=name;
        this.email=email;
    }
}
